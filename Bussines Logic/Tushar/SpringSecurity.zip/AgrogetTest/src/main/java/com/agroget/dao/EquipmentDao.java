package com.agroget.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agroget.entity.EquipmentInfoTable;
import com.agroget.entity.RenterEntity;
import com.agroget.rerpository.EquipmentRespository;

@Service
public class EquipmentDao {
	
	@Autowired
	private EquipmentRespository equipRepo;
	
	public List<EquipmentInfoTable> getAllEquipment()
	{
		return equipRepo.findAll();
		
	}

	public EquipmentInfoTable addEuipments(EquipmentInfoTable equip) {
		return equipRepo.save(equip);
	}

	public EquipmentInfoTable addEuipments(EquipmentInfoTable equip,RenterEntity renter) {
	//	RenterEntity re=new RenterEntity();
	/*	EquipmentInfoTable eq=new EquipmentInfoTable(
				 equip.getEquipment_status(),equip.getEquipment_description()
				,equip.getEquipment_name(),equip.getEquipment_rate(),equip.getEquipment_rate_type(),equip.getEquipment_type(),re);
		*/
		EquipmentInfoTable eq=new EquipmentInfoTable(equip,renter);
		eq.setEquipment_description("xxx");
		eq.setEquipment_name("uuwu838");
		eq.setEquipment_rate(23000);
		eq.setEquipment_rate_type("ssss");
		eq.setEquipment_status(1);
		eq.setRenter(renter);
		return equipRepo.save(eq);
	}

}
