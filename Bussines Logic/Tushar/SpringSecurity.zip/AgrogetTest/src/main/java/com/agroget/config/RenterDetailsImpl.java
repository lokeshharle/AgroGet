package com.agroget.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.agroget.entity.RenterEntity;
import com.agroget.rerpository.RenterRepository;

public class RenterDetailsImpl implements UserDetailsService{

	@Autowired
	RenterRepository renterRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		RenterEntity renter=renterRepo.getCustomerByName(username);
		if(renter==null) {
			throw new UsernameNotFoundException("Could not found User ");
		}
		RenterDetails renterDetails=new RenterDetails(renter);
		return renterDetails;
	}

}
