package com.agroget.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.agroget.entity.FarmerEntity;
import com.agroget.entity.RenterEntity;
import com.agroget.rerpository.FarmerRespository;
import com.agroget.rerpository.RenterRepository;

public class FarmerDetailsImpl  implements UserDetailsService{

	@Autowired
	FarmerRespository farmerRepo;
	
	@Autowired
	RenterRepository renterRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		FarmerEntity  farmer=farmerRepo.getFarmerByName(username);
		if(farmer==null) {
			
			RenterEntity renter=renterRepo.getCustomerByName(username);
			RenterDetails renterDetails=new RenterDetails(renter);
			return renterDetails;
		}
		 FarmerDetails farmerDetails=new FarmerDetails(farmer);
		 return farmerDetails;
	}

}
