package com.agroget.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agroget.entity.RenterEntity;
import com.agroget.rerpository.EquipmentInfoRepository;
import com.agroget.rerpository.RenterRepository;

@Service
public class RenterDao {
	
	@Autowired
	RenterRepository renterRepo;
	
	@Autowired
	EquipmentInfoRepository equipRepo;
	
	public void addRenterDetails(RenterEntity renterEntity) {
		renterRepo.save(renterEntity);
	}

	public RenterEntity loginRenter(String username, String password) {
		RenterEntity renter=new RenterEntity(username,password);
		System.out.println(renter.getRenterId());
		return renter;
	}

	public void addRentersInfo(RenterEntity renterEntity) {
		renterRepo.save(renterEntity);
	}

	
	
}
