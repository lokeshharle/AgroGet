package com.agroget.dao;

import java.sql.Blob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.agroget.controller.ImageController;
import com.agroget.entity.FarmerEntity;
import com.agroget.entity.ImageInfoTable;
import com.agroget.entity.RenterEntity;
import com.agroget.rerpository.ImageRepository;

@Service
public class ImageDao {
	
	@Autowired
	ImageRepository imageRepo;

	public ImageInfoTable addImages(MultipartFile file, String description) {
	
		return null;
	}


	
}
