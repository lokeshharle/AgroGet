package com.agroget.controller;



import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.agroget.dao.EquipmentDao;
import com.agroget.dao.FarmerDao;
import com.agroget.dao.OrderEquipmentDao;
import com.agroget.dao.OrderInfoDao;
import com.agroget.entity.EquipmentInfoTable;
import com.agroget.entity.FarmerEntity;
import com.agroget.entity.OrderEquipmentTable;
import com.agroget.entity.OrderInfoTable;

@Controller
public class FarmerController {
	
	@Autowired 
	 private BCryptPasswordEncoder passwordEncoder;
	
	@Autowired 
	FarmerDao farmerDao;
	
	@Autowired
	EquipmentDao equipmentDao;
	
	@Autowired
	OrderEquipmentDao orderEquipmentDao;
	
	@Autowired
	OrderInfoDao orderInfoDao;
	
	@GetMapping("/farm/home")
	public String home() {
		return "farmer";
	}
	@GetMapping("/farmer/login")
	public String home1() {
		return "logins";
	}
	
	@GetMapping("/home/login")
	public String login() {
		return "login";
	}
	
	@PostMapping("/addFarmer")
	public String addFarmer(@RequestParam String fname, @RequestParam String lname , 
			@RequestParam String mobile,  @RequestParam String email
			, @RequestParam String password ,
			 @RequestParam String address , @RequestParam String pincode)
	{
		String username =  email;
		FarmerEntity farmerEntity = new FarmerEntity(fname, lname, mobile, email, username, password, address, pincode);
		farmerEntity.setFarmerPassword(passwordEncoder.encode(farmerEntity.getFarmerPassword()));
		farmerDao.addFarmerDetails(farmerEntity);
		if(farmerEntity!=null) {
	    	return "index";
	    }
		return "farmer";
	}
	
	
	@PostMapping("/home/loginFarmer")
	public ModelAndView loginFarmer(@RequestParam String username,@RequestParam String password,HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		ModelAndView mv = new ModelAndView();
		FarmerEntity farmer = farmerDao.loginFarmer(username, password);
		if(Objects.isNull(farmer))
		{
			mv.setViewName("login");
		}
		else
		{
			System.out.println("Session Id " +   session.getId());
			mv.addObject("farmer",farmer);
			mv.setViewName("profile");
		}
		return mv;
	}
	
	@GetMapping("/home/logout")
	public ModelAndView logout(HttpSession session)
	{
		System.out.println("inside logout");
		session.invalidate();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("login");
		return mv;
	}

	
	


	@GetMapping("/home/showAllEquipments")
	public ModelAndView showAllEquipments()
	{
		ModelAndView mv = new ModelAndView();
		List<EquipmentInfoTable>  equipmentsList = equipmentDao.getAllEquipment();
		mv.addObject("equipments",equipmentsList);
		mv.setViewName("equipmentsView");
		return mv;
	}
	
	/*
	 * @GetMapping("/orderEquipment") public void orderEquipment(@RequestParam int
	 * id ) { System.out.println("yes "+id); OrderInfoTable oi = new
	 * OrderInfoTable(); orderInfoDao.saveOI(oi); OrderInfoTable oii =
	 * orderInfoDao.findById(oi.getOrderId()); System.out.println("oi" +
	 * oii.getOrderId()); }
	 */
	
	@GetMapping("/orderEquipment")
	public void orderEquipment(@RequestParam int id )
	{
		System.out.println("userid" + id);
		FarmerEntity farmerEntity = farmerDao.loginFarmer("prash@gmail.com", "prash");
		OrderInfoTable oi = new OrderInfoTable(new Date(), (byte) 1, 1230, farmerEntity);
		orderInfoDao.saveOI(oi);
		System.out.println(oi.getOrderId());
	}
	
	
	

}
