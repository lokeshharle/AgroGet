package com.agroget.rerpository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.agroget.entity.EquipmentInfoTable;

@Repository
public interface EquipmentRespository extends JpaRepository<EquipmentInfoTable, Integer> {

}
