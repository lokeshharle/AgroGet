package com.agroget.controller;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.agroget.dao.RenterDao;
import com.agroget.entity.EquipmentInfoTable;
import com.agroget.entity.RenterEntity;

@Controller
public class RenterController {
	
	@Autowired
	RenterDao renterDao;
	
	@Autowired 
	 private BCryptPasswordEncoder passwordEncoder;

	@GetMapping("/renter/login")
	public String renterHome() {
		return "logins";
	}
	
	@GetMapping("/renter")
	public String renterHome1() {
		return "renter";
	}

	@PostMapping("/renterAdd")
	public String addRenterDetails(@RequestParam String fname, @RequestParam String lname , 
			@RequestParam String mobile,  @RequestParam String email
			, @RequestParam String password ,@RequestParam String shop,
			@RequestParam String address,@RequestParam int pincode) {
		String username =  email;
		System.out.println(password);
		RenterEntity renterEntity = new RenterEntity(fname, lname, mobile, email, username, password, address, pincode,shop);
		
	        renterEntity.setRenterPassword(passwordEncoder.encode(renterEntity.getRenterPassword()));
	    	System.out.println(renterEntity.getRenterPassword());
			renterDao.addRentersInfo(renterEntity);
			return "renterLogin";
	}

	@PostMapping("/renterEquipments")
	public ModelAndView validateUser(@RequestParam String username,@RequestParam String password,
			HttpServletRequest request) {

		HttpSession session=request.getSession();
		ModelAndView mv=new ModelAndView();
		RenterEntity renter=renterDao.loginRenter(username, password);
		if(Objects.nonNull(renter)) {
			mv.addObject("renter", renter);
			mv.addObject("session", session);
			mv.setViewName("equipmentDetails");
		}
		else {
			mv.setViewName("login");
		}
		return mv;
	}
	@GetMapping("/renterLoging")
	public String loginRenter(HttpServletRequest request) {
		return "renterLogin";
	}
	
	@PostMapping("/renterSuccess")
	public String addedEquipments (@ModelAttribute EquipmentInfoTable equip, RenterEntity renter) {
		
		System.out.println(equip.getEquipment_id());
		System.out.println(equip);
		return null;
	}
	

}
