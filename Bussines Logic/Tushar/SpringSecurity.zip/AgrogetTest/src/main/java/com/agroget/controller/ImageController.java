package com.agroget.controller;

import java.sql.Blob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.agroget.dao.ImageDao;
import com.agroget.entity.ImageInfoTable;

@Controller
public class ImageController {
	
	@Autowired
	ImageDao imageDao;
	
	@GetMapping("/addimage")
	public String adder() {
		return "imagesave";
	}
	
	@PostMapping("/image")
	public String addImages(@RequestParam ("profileImage") MultipartFile file,
			 @RequestParam String description) {
		
		ImageInfoTable img=imageDao.addImages(file,description);	
		
		return description;
	
	}
/*	
	@PostMapping("/image")
	public String addImages(@RequestParam ("profileImage") MultipartFile file,
			 @RequestParam String description) {
		
		ImageInfoTable img=new ImageInfoTable();
		
		//processing and uploading file
		if(file.isEmpty()) {
			
		}
		else {
			img.setImageData(file.getOriginalFilename());
		}
		
		ImageController imgs=imageDao.saveImage(file,description);
		return null;
		
	}
*/
}
