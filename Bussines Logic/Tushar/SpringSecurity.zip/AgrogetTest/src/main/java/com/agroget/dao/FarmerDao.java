package com.agroget.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.agroget.entity.FarmerEntity;
import com.agroget.rerpository.FarmerRespository;


@Service
public class FarmerDao {
	
	@Autowired
	FarmerRespository farmerRepo;
	
	public void addFarmerDetails(FarmerEntity farmer)
	{
		farmerRepo.save(farmer);
	}
	
	public FarmerEntity loginFarmer(String username,String password)
	{
		FarmerEntity farmerEntity =new FarmerEntity(username, password); 
	//	FarmerEntity farmerEntity = farmerRepo.loginFarmer(username, password);
		return farmerEntity;
		
	}
	
	
	

}
