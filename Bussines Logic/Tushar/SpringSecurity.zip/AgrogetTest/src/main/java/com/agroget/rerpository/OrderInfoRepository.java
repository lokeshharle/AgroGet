package com.agroget.rerpository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.agroget.entity.OrderInfoTable;

@Repository
public interface OrderInfoRepository extends JpaRepository<OrderInfoTable, Integer>{

}
