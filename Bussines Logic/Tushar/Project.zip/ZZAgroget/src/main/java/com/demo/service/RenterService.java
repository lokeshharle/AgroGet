package com.demo.service;

import com.demo.pojo.RenterEntity;

public interface RenterService {

	RenterEntity addRenter(RenterEntity renter);

}
