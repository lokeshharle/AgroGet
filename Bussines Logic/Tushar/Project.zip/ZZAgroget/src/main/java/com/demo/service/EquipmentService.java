package com.demo.service;

import com.demo.pojo.EquipmentInfoTable;

public interface EquipmentService {

	EquipmentInfoTable addEquipments(EquipmentInfoTable equip);

}
