package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.pojo.EquipmentInfoTable;
import com.demo.service.EquipmentService;

@Controller
public class EquipmentController {

	@Autowired
	EquipmentService equipmentService;

	//after successfull login user will redirect on this url
	@GetMapping("/fillDetails")
	public String fillEquipments() {

		return "equipmentdetails";
	}

	@PostMapping("/fill")
	public String filledEquipments(@RequestParam String equipmentname, 
			@RequestParam String equipmenttype , 
			@RequestParam String equipmentratetype, 
			@RequestParam double equipmentrate,
			@RequestParam String equipmentdescription ,
			@RequestParam int equipmentstatus) {

		EquipmentInfoTable eq=new EquipmentInfoTable(equipmentname,equipmenttype,
				equipmentratetype,equipmentrate,equipmentdescription,equipmentstatus);
		EquipmentInfoTable equip= equipmentService.addEquipments(eq);	

		if(equip!=null) {
			System.out.println("added successfully !!!!!!!!");
		}
		return "equipmentdetails";
	}
}
