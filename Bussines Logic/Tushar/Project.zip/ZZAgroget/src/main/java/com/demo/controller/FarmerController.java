package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.pojo.FarmerEntity;
import com.demo.service.FarmerService;

@Controller
public class FarmerController {

	@Autowired
	FarmerService farmerService;
	
	@GetMapping("/home")
	public String home() {
		return "farmer";
	}

	//@PostMapping("/addFarmer")
	public String addFarmer(@ModelAttribute FarmerEntity farmer) {
	    try {
	    	FarmerEntity farm=farmerService.addFarmerDetails(farmer);
		    if(farm!=null) {
		    	return "index";       
		    }
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "farmer";
	}
	
	@PostMapping("/addFarmer")
	public String addF(@RequestParam String fname, @RequestParam String lname , 
			@RequestParam String mobile,  @RequestParam String email,
			 @RequestParam String password ,
			 @RequestParam String address ,  @RequestParam String pincode)
	{
		String username=email;
		System.out.println(username);
		FarmerEntity farmer = new FarmerEntity(fname, lname, mobile, email, username, password, address, pincode);
		farmerService.addFarmerDetails(farmer);
	    if(farmer!=null) {
	    	return "index";
	    }
		return "farmer";
		
	}
/*	
	@PostMapping("/login")
	public String login(@RequestParam String email,
			@RequestParam String username)
	{
		FarmerEntity farmer = farmerService.loginFarmer(username, username);
		if(farmer!=null) {
	    	return "profile";
	    }
		return "farmer";
	}
	
	
	
	
	@PostMapping("/addFarmers")
	public String fillFarmer(@RequestParam("email") String email,
			                 @RequestParam("password") String pass) {
		
		FarmerEntity ent=farmerService.include(email,pass);
		System.out.println(ent);
		return "index";
	}
*/	
	
	
}
