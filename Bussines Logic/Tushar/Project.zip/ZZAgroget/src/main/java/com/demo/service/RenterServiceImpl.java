package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.RenterDao;
import com.demo.pojo.RenterEntity;

@Service
public class RenterServiceImpl implements RenterService {
	
	@Autowired
	RenterDao renterDao;

	@Override
	public RenterEntity addRenter(RenterEntity renter) {
		return renterDao.save(renter);
	}
	
	
	
}
