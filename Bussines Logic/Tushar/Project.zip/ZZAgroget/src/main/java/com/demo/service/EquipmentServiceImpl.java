package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.EquipmentDao;
import com.demo.pojo.EquipmentInfoTable;

@Service
public class EquipmentServiceImpl implements EquipmentService {

	@Autowired
	EquipmentDao equipmentDao;
	
	@Override
	public EquipmentInfoTable addEquipments(EquipmentInfoTable equip) {
		return equipmentDao.save(equip);
	}

}
