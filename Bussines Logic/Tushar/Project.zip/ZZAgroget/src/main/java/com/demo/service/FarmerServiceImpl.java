package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.FarmerDao;
import com.demo.pojo.FarmerEntity;

@Service
public class FarmerServiceImpl implements FarmerService{

	@Autowired
	FarmerDao farmerDao;

	@Override
	public FarmerEntity addFarmerDetails(FarmerEntity farmer) {
		FarmerEntity entity=farmerDao.save(farmer);
		return entity;
	}

	@Override
	public FarmerEntity include(String email, String pass) {
		FarmerEntity ent=new FarmerEntity(email, pass);
		return farmerDao.save(ent);
	}
}
