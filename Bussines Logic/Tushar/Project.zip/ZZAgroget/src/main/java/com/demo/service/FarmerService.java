package com.demo.service;

import com.demo.pojo.FarmerEntity;

public interface FarmerService {

	FarmerEntity addFarmerDetails(FarmerEntity farmer);

	FarmerEntity include(String email, String pass);

}
